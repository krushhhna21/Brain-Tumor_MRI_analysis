# Brain Tumor MRI Classifier - Quick Start Guide

## Get Started in 5 Minutes

---

## Option 1: Docker (Recommended)

```bash
# Clone repository
git clone https://github.com/yourusername/Brain-Tumor-MRI-Classifier.git
cd Brain-Tumor-MRI-Classifier

# Start with Docker Compose
docker-compose up -d

# Access services
# API: http://localhost:8000
# Web UI: http://localhost:3000
# Docs: http://localhost:8000/docs
```

---

## Option 2: Local Installation

### Prerequisites
- Python 3.9+
- CUDA 11.8+ (for GPU support)
- 8GB+ RAM

### Installation

```bash
# Clone repository
git clone https://github.com/yourusername/Brain-Tumor-MRI-Classifier.git
cd Brain-Tumor-MRI-Classifier

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Download pre-trained models
python scripts/download_models.py

# Start API server
uvicorn src.api.main:app --reload
```

---

## Usage Examples

### Python API Client

```python
from brain_tumor_classifier import EnsembleClassifier
import matplotlib.pyplot as plt

# Initialize classifier
classifier = EnsembleClassifier.from_pretrained('models/ensemble')

# Make prediction
result = classifier.predict('mri_scan.jpg')

print(f"Prediction: {result.predicted_class}")
print(f"Confidence: {result.confidence:.2%}")
print(f"Uncertainty: {result.uncertainty:.2%}")

# Visualize Grad-CAM
fig = classifier.explain('mri_scan.jpg')
plt.show()
```

### REST API

```bash
# Make prediction
curl -X POST "http://localhost:8000/predict" \
  -H "accept: application/json" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@mri_scan.jpg" \
  -F "return_gradcam=true"
```

**Response:**
```json
{
  "predicted_class": "glioma",
  "confidence": 0.9847,
  "all_probabilities": {
    "glioma": 0.9847,
    "meningioma": 0.0089,
    "pituitary": 0.0042,
    "no_tumor": 0.0022
  },
  "uncertainty": 0.0234,
  "model_agreement": 1.0,
  "gradcam_url": "/gradcam/temp_abc123.png",
  "processing_time_ms": 118.5
}
```

### Web Interface

```bash
# Start web UI
cd web
npm install
npm start

# Open http://localhost:3000
```

---

## Training Your Own Model

```python
from src.models import EfficientNetV2Classifier
from src.data import BrainTumorDataset
from src.training import Trainer

# Load data
dataset = BrainTumorDataset('data/processed')
train_ds, val_ds, test_ds = dataset.load_data()

# Create model
model = EfficientNetV2Classifier(num_classes=4)

# Train
trainer = Trainer(
    model=model,
    train_dataset=train_ds,
    val_dataset=val_ds,
    epochs=50,
    learning_rate=1e-3
)

history = trainer.train()

# Evaluate
trainer.evaluate(test_ds)
```

---

## Model Performance

| Metric | Value |
|--------|-------|
| Accuracy | 98.5% |
| Precision | 98.3% |
| Recall | 98.4% |
| F1-Score | 98.3% |
| AUC-ROC | 0.997 |
| Inference Time | ~120ms |

---

## Troubleshooting

### GPU Not Detected
```bash
# Check CUDA installation
nvidia-smi

# Verify TensorFlow GPU
python -c "import tensorflow as tf; print(tf.config.list_physical_devices('GPU'))"
```

### Out of Memory
```bash
# Reduce batch size in config
export BATCH_SIZE=16

# Or use mixed precision
export MIXED_PRECISION=true
```

---

## Next Steps

1. Read the [full documentation](docs/)
2. Try the [Jupyter notebooks](notebooks/)
3. Deploy to [cloud](docs/DEPLOYMENT.md)
4. Contribute to the project

---

## Support

- GitHub Issues: [Report bugs](https://github.com/yourusername/Brain-Tumor-MRI-Classifier/issues)
- Discussions: [Ask questions](https://github.com/yourusername/Brain-Tumor-MRI-Classifier/discussions)
- Email: support@example.com
